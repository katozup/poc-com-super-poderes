import './_TitleH1.scss';

const TitleH1 = ({ text }) => (
  <h1 className="main-title">
    {text}
  </h1>
);

export default TitleH1;
