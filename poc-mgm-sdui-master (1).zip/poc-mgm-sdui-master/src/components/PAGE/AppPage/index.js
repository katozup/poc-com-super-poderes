import './_AppPage.scss';

const AppPage = ({ children }) => (
  <div className="app-wrapper">
    { children }
  </div>
);

export default AppPage;
